// app/api/lostark-market/route.ts
import { NextResponse } from "next/server";
import { request } from "undici";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const API_URL = "https://developer-lostark.game.onstove.com/markets/items";

// ✅ 서버 전용(절대 NEXT_PUBLIC_로 하지 말기)
const JWT = process.env.LOSTARK_OPENAPI_JWT;

// ---- 간단한 인메모리 캐시 + in-flight dedupe (로컬/단일 인스턴스에 효과 큼) ----
type CacheEntry = { exp: number; data: any };
const cache = new Map<string, CacheEntry>();
const inflight = new Map<string, Promise<any>>();

// ---- 분당 100회(= 약 600ms당 1회) 수준으로 강제 스로틀 ----
let lastCallAt = 0;
async function throttle100PerMin() {
    const now = Date.now();
    const wait = Math.max(0, 650 - (now - lastCallAt));
    if (wait) await new Promise((r) => setTimeout(r, wait));
    lastCallAt = Date.now();
}

function cacheKey(obj: any) {
    return JSON.stringify(obj);
}

export async function GET(req: Request) {
    if (!JWT) {
        return NextResponse.json(
            { error: "Missing env LOSTARK_OPENAPI_JWT" },
            { status: 500 }
        );
    }

    const { searchParams } = new URL(req.url);

    // 쿼리 파라미터로 조절 (필요한 것만 최소)
    const CategoryCode = Number(searchParams.get("categoryCode") || "0");
    const ItemName = (searchParams.get("itemName") || "").trim();
    const PageNo = Number(searchParams.get("pageNo") || "1");
    const Sort = (searchParams.get("sort") || "").trim(); // 예: "RECENT_PRICE" 등
    const SortCondition = (searchParams.get("sortCondition") || "").trim(); // "ASC"/"DESC"
    const ttlSec = Number(searchParams.get("ttlSec") || "15"); // 기본 15초 캐시

    // OpenAPI는 POST body로 검색옵션 전달 (공식 가이드 참고) :contentReference[oaicite:2]{index=2}
    const body: Record<string, any> = {
        PageNo,
    };
    if (CategoryCode) body.CategoryCode = CategoryCode;
    if (ItemName) body.ItemName = ItemName;
    if (Sort) body.Sort = Sort;
    if (SortCondition) body.SortCondition = SortCondition;

    const key = cacheKey(body);
    const now = Date.now();

    // 1) 캐시 히트
    const hit = cache.get(key);
    if (hit && hit.exp > now) {
        return NextResponse.json({
            cached: true,
            ttlSec,
            query: body,
            data: hit.data,
        });
    }

    // 2) 같은 요청이 이미 진행 중이면 그 Promise를 공유
    if (inflight.has(key)) {
        const data = await inflight.get(key)!;
        return NextResponse.json({
            cached: false,
            deduped: true,
            ttlSec,
            query: body,
            data,
        });
    }

    const p = (async () => {
        const ac = new AbortController();
        const timeout = setTimeout(() => ac.abort(), 10_000);

        try {
            await throttle100PerMin();

            const res = await request(API_URL, {
                method: "POST",
                headers: {
                    accept: "application/json",
                    "content-type": "application/json",
                    // bearer 토큰 필요 :contentReference[oaicite:3]{index=3}
                    authorization: `bearer ${JWT}`,
                },
                body: JSON.stringify(body),
                signal: ac.signal,
            });

            // 429(쿼터 초과) 등 에러 처리 (공식 에러 코드 표) :contentReference[oaicite:4]{index=4}
            const text = await res.body.text();
            let json: any = null;
            try {
                json = text ? JSON.parse(text) : null;
            } catch {
                // json 파싱 실패해도 원문 텍스트 남김
                json = { raw: text };
            }

            if (res.statusCode !== 200) {
                // 에러여도 "직전 캐시"가 있으면 그걸 반환하는 전략(안정성↑)
                const fallback = cache.get(key);
                if (fallback) return fallback.data;

                throw new Error(`Upstream status ${res.statusCode}`);
            }

            // 캐시 저장
            cache.set(key, { exp: Date.now() + ttlSec * 1000, data: json });
            return json;
        } finally {
            clearTimeout(timeout);
        }
    })();

    inflight.set(key, p);

    try {
        const data = await p;
        return NextResponse.json({
            cached: false,
            ttlSec,
            query: body,
            data,
        });
    } catch (e: any) {
        return NextResponse.json(
            { error: "fetch failed", detail: String(e?.message || e), query: body },
            { status: 502 }
        );
    } finally {
        inflight.delete(key);
    }
}
