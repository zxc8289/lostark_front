export default function DpsSharePage() {
    return (
        <section>
            <h1 className="text-2xl font-bold">딜 지분</h1>
            <p className="mt-2 text-gray-600">레이드 딜 지분/로그 분석 프리셋.</p>
        </section>
    );
}
