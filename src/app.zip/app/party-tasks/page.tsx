export default function PartyTasksPage() {
    return (
        <section>
            <h1 className="text-2xl font-bold">파티 숙제</h1>
            <p className="mt-2 text-gray-600">파티원 숙제 현황을 공유/체크.</p>
        </section>
    );
}
