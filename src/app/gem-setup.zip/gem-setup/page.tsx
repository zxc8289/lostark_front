'use client';

import { useEffect, useMemo, useRef, useState } from "react";
import { loadState, makeInitialState, saveState } from "../lib/arcgrid/storage";
import { baseWillBySubType, optimizeAll, optimizeExtremeBySequence } from "../lib/arcgrid/optimizer";
import { Gem } from "@/types/gem";
import { CoreDef } from "../lib/arcgrid/types";
import { ORDER_PERMS } from "../lib/arcgrid/constants";
import Step from "../components/arcgrid/Step";
import InventoryPanel from "../components/arcgrid/InventoryPanel";
import ResultsPanel from "../components/arcgrid/ResultsPanel";
import ActionBar from "../components/arcgrid/ActionBar";
import QuickAddModal, { QuickDraft } from "../components/arcgrid/QuickAddModal";


export default function ArcGridPage() {
    const [state, setState] = useState(makeInitialState);
    const [resultPack, setResultPack] = useState<ReturnType<typeof optimizeExtremeBySequence> | null>(null);
    const [mode, setMode] = useState<'default' | 'extreme'>('default');
    const [orderPermIndex, setOrderPermIndex] = useState(0);
    const [showQuick, setShowQuick] = useState(false);
    const fileRef = useRef<HTMLInputElement | null>(null);
    const [toast, setToast] = useState<string | null>(null);

    useEffect(() => { setState(loadState()); }, []);
    useEffect(() => { saveState(state); }, [state]);

    const invCount = state.inventory.order.length + state.inventory.chaos.length;
    const selectedCoreCount = state.cores.filter(c => c.enabled).length;
    const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(null), 1400); };

    function addGem(family: 'order' | 'chaos') {
        const g: Gem = {
            id: crypto?.randomUUID?.() || Math.random().toString(36).slice(2),
            family,
            subType: family === 'order' ? '안정' : '침식',
            baseWill: baseWillBySubType(family === 'order' ? '안정' : '침식'),
            options: [
                { name: '의지력 효율', lv: 4, fixed: true },
                { name: '코어 포인트', lv: 3, fixed: true },
                { name: '보스 피해', lv: 5 },
                { name: '공격력', lv: 3 },
            ],
        };
        setState(st => ({ ...st, inventory: { ...st.inventory, [family]: [...st.inventory[family], g] } }));
    }
    function updateGem(family: 'order' | 'chaos', id: string, patch: Partial<Gem>) {
        setState(st => ({
            ...st,
            inventory: {
                ...st.inventory,
                [family]: st.inventory[family].map(g => g.id === id ? { ...g, ...patch } : g)
            }
        }));
    }
    function updateGemOption(
        family: 'order' | 'chaos', id: string, idx: number, patch: Partial<Gem['options'][number]>
    ) {
        setState(st => ({
            ...st,
            inventory: {
                ...st.inventory,
                [family]: st.inventory[family].map(g => {
                    if (g.id !== id) return g;
                    const opts = g.options.slice();
                    const next: any = { ...opts[idx], ...patch };
                    if (Object.prototype.hasOwnProperty.call(patch, 'name') && next.lv == null) next.lv = 1;
                    if (next.lv != null) next.lv = Number(next.lv) || 1;
                    opts[idx] = next;
                    return { ...g, options: opts };
                })
            }
        }));
    }
    function removeGem(family: 'order' | 'chaos', id: string) {
        setState(st => ({ ...st, inventory: { ...st.inventory, [family]: st.inventory[family].filter(g => g.id !== id) } }));
    }
    function resetInventory() {
        setState(st => ({ ...st, inventory: { order: [], chaos: [] } }));
        showToast("인벤토리를 비웠습니다");
    }
    function saveToFile() {
        const data = JSON.stringify({ inventory: state.inventory }, null, 2);
        const blob = new Blob([data], { type: "application/json" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "arcgrid_inventory.json";
        a.click();
        URL.revokeObjectURL(a.href);
        showToast("파일로 저장했어요");
    }
    function loadFromFile(e: React.ChangeEvent<HTMLInputElement>) {
        const f = e.target.files?.[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = () => {
            try {
                const parsed = JSON.parse(String(reader.result));
                setState(st => ({ ...st, inventory: parsed.inventory || st.inventory }));
                showToast("파일에서 불러왔어요");
            } catch {
                showToast("불러오기에 실패했습니다");
            }
        };
        reader.readAsText(f);
    }

    function run() {
        const cores = state.cores.filter(c => c.enabled);
        if (!cores.length) return showToast("선택된 코어가 없어요");
        if (invCount === 0) return showToast("인벤토리에 젬을 추가해 주세요");

        const constraints = Object.fromEntries(state.cores.map(c => [c.key, { minPts: c.minPts, maxPts: c.maxPts }]));

        if (mode === 'default') {
            const pack = optimizeAll(cores as CoreDef[], state.params, state.inventory, constraints);
            setResultPack({ plan: pack, focusKey: cores[0].key });
        } else {
            const seq = ORDER_PERMS[orderPermIndex];
            const ext = optimizeExtremeBySequence(seq, cores as CoreDef[], state.params, state.inventory, constraints);
            setResultPack(ext);
        }
        showToast("최적 조합을 계산했어요");
    }

    const gemById = useMemo(() => {
        const m = new Map<string, Gem>();
        for (const g of state.inventory.order) m.set(g.id, g);
        for (const g of state.inventory.chaos) m.set(g.id, g);
        return m;
    }, [state.inventory]);

    return (
        <div className="max-w-[1100px] mx-auto px-4">
            <header className="flex items-center justify-between py-3 border-b mb-4">
                <div>
                    <div className="font-bold text-lg">ArcGrid</div>
                    <div className="text-xs text-zinc-500">코어 · 젬 최적화 탐색기</div>
                </div>
                <div className="flex items-center gap-2">
                    <button className="px-3 py-1.5 rounded-xl border" onClick={saveToFile}>인벤 저장</button>
                    <label className="px-3 py-1.5 rounded-xl border cursor-pointer">
                        불러오기
                        <input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={loadFromFile} />
                    </label>
                </div>
            </header>

            <div className="flex flex-col gap-4">
                {/* Step 1 */}
                <section className="border rounded-2xl p-4">
                    <Step title="1. 코어 선택" subtitle="사용할 코어와 포인트 범위를 지정하세요" />
                    <div className="grid grid-cols-4 gap-2 mt-3 text-sm text-zinc-600">
                        <div>코어</div><div>등급</div><div>최소 포인트</div><div>최대 포인트</div>
                        {state.cores.map((c, idx) => (
                            <Row key={c.key}
                                core={c}
                                onToggle={(checked) => setState(st => { const cs = st.cores.slice(); cs[idx] = { ...c, enabled: checked }; return { ...st, cores: cs }; })}
                                onGrade={(g) => setState(st => { const cs = st.cores.slice(); cs[idx] = { ...c, grade: g }; return { ...st, cores: cs }; })}
                                onMin={(v) => setState(st => { const cs = st.cores.slice(); cs[idx] = { ...c, minPts: Number(v || 0) }; return { ...st, cores: cs }; })}
                                onMax={(v) => setState(st => { const cs = st.cores.slice(); cs[idx] = { ...c, maxPts: Number(v || 0) }; return { ...st, cores: cs }; })}
                            />
                        ))}
                    </div>
                </section>

                {/* Step 2 */}
                <section className="border rounded-2xl p-4">
                    <Step title="2. 보유 젬 입력" subtitle="계열별로 젬을 추가하고 옵션을 입력하세요" />
                    <div className="grid md:grid-cols-2 gap-4 mt-3">
                        <InventoryPanel
                            title="질서 인벤토리"
                            family="order"
                            list={state.inventory.order}
                            params={state.params as any}
                            onAdd={() => addGem('order')}
                            onUpdate={updateGem}
                            onUpdateOption={updateGemOption}
                            onRemove={removeGem}
                        />
                        <InventoryPanel
                            title="혼돈 인벤토리"
                            family="chaos"
                            list={state.inventory.chaos}
                            params={state.params as any}
                            onAdd={() => addGem('chaos')}
                            onUpdate={updateGem}
                            onUpdateOption={updateGemOption}
                            onRemove={removeGem}
                        />
                    </div>
                    <div className="flex gap-2 mt-3">
                        <button className="px-3 py-1.5 rounded-xl border" onClick={() => setShowQuick(true)}>빠른 추가(텍스트)</button>
                        <button className="px-3 py-1.5 rounded-xl border" onClick={resetInventory}>인벤 비우기</button>
                    </div>
                </section>

                {/* Step 3 */}
                <section className="border rounded-2xl p-4">
                    <Step title="3. 결과" subtitle="코어별 최적 조합과 수치를 확인하세요" />
                    <div className="flex gap-2 mt-3">
                        <button className={`px-3 py-1.5 rounded-xl border ${mode === 'default' ? 'bg-blue-600 text-white border-blue-600' : ''}`} onClick={() => setMode('default')}>기본</button>
                        <button className={`px-3 py-1.5 rounded-xl border ${mode === 'extreme' ? 'bg-blue-600 text-white border-blue-600' : ''}`} onClick={() => setMode('extreme')}>우선순위 변경</button>
                    </div>

                    {!resultPack ? (
                        <div className="border border-dashed rounded-xl p-4 text-center text-zinc-600 mt-3">
                            아래 오른쪽의 <b>최적화</b> 버튼을 눌러 조합을 계산해 보세요.
                        </div>
                    ) : (
                        <ResultsPanel
                            modeLabel={mode === 'extreme'
                                ? `극(순서: ${ORDER_PERMS[orderPermIndex].map(k => state.cores.find(c => c.key === k)?.label).filter(Boolean).join(' > ')})`
                                : '기본'}
                            plan={resultPack.plan}
                            cores={state.cores}
                            gemById={gemById}
                            {...(mode === 'extreme' ? { orderPermIndex, onChangeOrderPerm: (i: number) => setOrderPermIndex(i) } : {})}
                        />
                    )}
                </section>
            </div>

            <ActionBar coreCount={selectedCoreCount} invCount={invCount} onRun={run} />
            {toast && <div className="fixed bottom-20 right-5 px-3 py-2 rounded-xl bg-zinc-900 text-white text-sm shadow">{toast}</div>}

            {showQuick && (
                <QuickAddModal
                    onClose={() => setShowQuick(false)}
                    onConfirm={(drafts: QuickDraft[]) => {
                        setState(st => {
                            const next = { ...st, inventory: { ...st.inventory } };
                            for (const d of drafts) {
                                const g: Gem = {
                                    id: crypto?.randomUUID?.() || Math.random().toString(36).slice(2),
                                    family: d.family,
                                    subType: d.subType,
                                    baseWill: d.base,
                                    options: [
                                        { name: '의지력 효율', lv: d.effLv, fixed: true },
                                        { name: '코어 포인트', lv: d.pts, fixed: true },
                                        ...d.opts.slice(0, 2).map(o => ({ name: o.name, lv: o.lv })),
                                    ],
                                };
                                (next.inventory as any)[g.family] = [...(next.inventory as any)[g.family], g];
                            }
                            return next;
                        });
                        setShowQuick(false);
                        showToast(`젬 ${drafts.length}개 추가`);
                    }}
                />
            )}
        </div>
    );
}

function Row({
    core, onToggle, onGrade, onMin, onMax
}: { core: CoreDef; onToggle: (b: boolean) => void; onGrade: (g: CoreDef['grade']) => void; onMin: (v: number) => void; onMax: (v: number) => void }) {
    return (
        <>
            <div className="flex items-center gap-2">
                <label className="inline-flex items-center gap-2">
                    <input type="checkbox" className="size-4" checked={core.enabled} onChange={e => onToggle(e.target.checked)} />
                    <span className={`px-2.5 py-1 rounded-full text-xs ${core.family === 'order' ? 'bg-blue-50 text-blue-700' : 'bg-rose-50 text-rose-700'}`}>
                        {core.label}
                    </span>
                </label>
            </div>
            <div>
                <select className="border rounded-xl px-3 py-1.5 text-sm" value={core.grade} onChange={e => onGrade(e.target.value as any)}>
                    <option value="heroic">영웅(9)</option>
                    <option value="legend">전설(12)</option>
                    <option value="relic">유물(15)</option>
                    <option value="ancient">고대(17)</option>
                </select>
            </div>
            <div>
                <input type="number" className="border rounded-xl px-3 py-1.5 text-sm w-full" value={core.minPts} onChange={e => onMin(Number(e.target.value || 0))} />
            </div>
            <div>
                <input type="number" className="border rounded-xl px-3 py-1.5 text-sm w-full" value={core.maxPts} onChange={e => onMax(Number(e.target.value || 0))} />
            </div>
        </>
    );
}
