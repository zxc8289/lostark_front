'use client';

import { CoreDef, PlanPack } from "@/app/lib/arcgrid/types";
import Stat from "./Stat";
import { Gem } from "@/types/gem";
import { CORE_WILL_BY_GRADE, ORDER_PERMS, STAT_ALIAS } from "@/app/lib/arcgrid/constants";
import { effectiveWillRequired, gemCorePoints } from "@/app/lib/arcgrid/optimizer";

export default function ResultsPanel({
    modeLabel, plan, cores, gemById, orderPermIndex, onChangeOrderPerm
}: {
    modeLabel: string;
    plan: PlanPack;
    cores: CoreDef[];
    gemById: Map<string, Gem>;
    orderPermIndex?: number;
    onChangeOrderPerm?: (idx: number) => void;
}) {
    const enabled = cores.filter(c => c.enabled);

    return (
        <>
            {typeof orderPermIndex === 'number' && onChangeOrderPerm && (
                <div className="flex items-center gap-2 -mt-1 mb-3 flex-wrap">
                    <span className="text-sm text-zinc-600">집중 순서(질서):</span>
                    <select className="border rounded-xl px-3 py-1.5 text-sm" value={orderPermIndex}
                        onChange={e => onChangeOrderPerm(Number(e.target.value))}>
                        {ORDER_PERMS.map((perm, idx) => (
                            <option key={idx} value={idx}>
                                {perm.map(k => cores.find(c => c.key === k)?.label).filter(Boolean).join(' > ')}
                            </option>
                        ))}
                    </select>
                </div>
            )}

            <div className="text-sm text-zinc-600 mb-2">
                보기 모드: <b className="text-zinc-900">{modeLabel}</b>
            </div>

            <div className="grid grid-cols-1 gap-3">
                {enabled.map(c => {
                    const item = plan.answer[c.key];
                    const ids = (item?.ids || []).filter(Boolean) as string[];

                    return (
                        <div key={c.key} className="border rounded-xl p-3">
                            <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                    <span className={`px-2.5 py-1 rounded-full text-xs ${c.family === 'order' ? 'bg-blue-50 text-blue-700' : 'bg-rose-50 text-rose-700'}`}>{c.label}</span>
                                    <span className="text-xs text-zinc-600">의지력 {CORE_WILL_BY_GRADE[c.grade]} · 포인트 {c.minPts}~{c.maxPts}</span>
                                </div>
                            </div>

                            <div className="flex flex-wrap gap-2 mb-2">
                                {ids.length ? ids.map((id, i) => {
                                    const g = gemById.get(id);
                                    if (!g) return null;
                                    const need = effectiveWillRequired(g, { efficiencyReductionByPoint: { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5 } } as any);
                                    const pts = gemCorePoints(g);
                                    const statText = formatDpsStats(g);
                                    return (
                                        <span key={id} className="inline-flex items-center border rounded-full px-2.5 py-1 text-xs">
                                            {`(${need},${pts})`}{statText && <span className="mx-1">·</span>}{statText}
                                            <small className="ml-1 opacity-60">#{i + 1}</small>
                                        </span>
                                    );
                                }) : (
                                    <span className="text-sm text-zinc-500">선정된 젬 없음</span>
                                )}
                                {item?.reason && (
                                    <span className="inline-flex items-center border border-amber-400 bg-amber-50 rounded-full px-2.5 py-1 text-xs text-amber-700">
                                        {item.reason}
                                    </span>
                                )}
                            </div>

                            <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                                <Stat title="코어 포인트 합" value={item?.res?.pts ?? "-"} />
                                <Stat title="달성 임계치" value={item?.t ?? "-"} />
                                <Stat title="의지력 잔여" value={item?.res ? item.res.remain : "-"} />
                                <Stat title="활성 슬롯" value={item?.res?.activated?.filter(Boolean).length ?? "-"} />
                                <Stat title="스탯 점수(딜러)" value={item?.res ? Number(item.res.flexScore).toFixed(2) : "-"} />
                            </div>

                            {item?.res && (
                                <div className="text-xs text-zinc-600 mt-2">
                                    보스:{item.res.flex?.["보스 피해"] ?? 0} / 추가:{item.res.flex?.["추가 피해"] ?? 0} / 공:{item.res.flex?.["공격력"] ?? 0}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </>
    );
}

function formatDpsStats(gem: Gem) {
    const o2 = gem.options?.[2];
    const o3 = gem.options?.[3];
    const show = (o?: { name: string; lv: number }) => {
        if (!o?.name) return null;
        const key = (o.name || "").trim();
        const lv = Number(o.lv ?? 1) || 1;
        return `${STAT_ALIAS[key] ?? key}${lv}`;
    };
    return [show(o2), show(o3)].filter(Boolean).join(" ");
}
