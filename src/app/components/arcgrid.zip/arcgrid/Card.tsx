'use client';
import { ReactNode } from "react";

export default function Card({
    children, className = ""
}: { children: ReactNode; className?: string }) {
    return (
        <div
            className={[
                "rounded-2xl border shadow-sm",
                "bg-white/90 dark:bg-zinc-900/80",
                "border-zinc-200/80 dark:border-zinc-800",
                "hover:shadow-md transition-shadow",
                className,
            ].join(" ")}
        >
            {children}
        </div>
    );
}

export function CardHeader({ title, right }: { title: ReactNode; right?: ReactNode }) {
    return (
        <div className="relative overflow-hidden rounded-t-2xl">
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/90 via-violet-500/80 to-fuchsia-500/70 opacity-80" />
            <div className="relative flex items-center justify-between px-4 py-3">
                <div className="text-white font-semibold">{title}</div>
                {right && <div className="flex items-center gap-2">{right}</div>}
            </div>
        </div>
    );
}

export function CardBody({ children, className = "" }: { children: ReactNode; className?: string }) {
    return <div className={["p-4", className].join(" ")}>{children}</div>;
}
