export default function ActionBar({ coreCount, invCount, onRun }: { coreCount: number; invCount: number; onRun: () => void }) {
    return (
        <footer className="sticky bottom-0 left-0 right-0 bg-white/80 backdrop-blur border-t px-4 py-3 flex items-center gap-3">
            <div className="text-sm text-zinc-600">선택 코어 <b className="ml-1 text-zinc-900">{coreCount}</b></div>
            <div className="text-sm text-zinc-600">보유 젬 <b className="ml-1 text-zinc-900">{invCount}</b></div>
            <div className="grow" />
            <button className="px-4 py-2 rounded-xl bg-blue-600 text-white font-semibold" onClick={onRun}>최적화</button>
        </footer>
    )
}