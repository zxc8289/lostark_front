'use client';

import Field from "./Field";

import type { Gem, Params } from "@/app/lib/arcgrid/types";
import { FAMILY_LABEL, FLEX_OPTION_POOL, SUB_TYPES } from "@/app/lib/arcgrid/constants";
import { baseWillBySubType, effectiveWillRequired, gemCorePoints, getGemOption } from "@/app/lib/arcgrid/optimizer";
import { CardBody, CardHeader } from "./Card";
import Card from "../Card";
import Badge from "./Badget";

export default function InventoryPanel({
    title, family, list, params, onAdd, onUpdate, onUpdateOption, onRemove
}: {
    title: string;
    family: 'order' | 'chaos';
    list: Gem[];
    params: Params;
    onAdd: () => void;
    onUpdate: (family: 'order' | 'chaos', id: string, patch: Partial<Gem>) => void;
    onUpdateOption: (family: 'order' | 'chaos', id: string, idx: number, patch: Partial<Gem['options'][number]>) => void;
    onRemove: (family: 'order' | 'chaos', id: string) => void;
}) {
    const tone = family === "order" ? "blue" : "rose";

    return (
        <Card className="overflow-hidden">
            <CardHeader
                title={<span className="flex items-center gap-2">
                    <Badge tone={tone}>{FAMILY_LABEL[family]} 인벤토리</Badge>
                    <span className="opacity-90 text-white/90 text-sm">{title}</span>
                </span>}
                right={
                    <button
                        className="rounded-xl bg-white/10 text-white hover:bg-white/20 transition-colors text-sm px-3 py-1.5"
                        onClick={onAdd}
                        title="+ 젬 추가"
                    >
                        + 젬 추가
                    </button>
                }
            />
            <CardBody>
                {list.length === 0 ? (
                    <div className="border border-dashed rounded-2xl p-6 text-center text-zinc-600 bg-zinc-50 dark:bg-zinc-900/40 dark:border-zinc-800">
                        아직 젬이 없습니다. 오른쪽 상단의 <b>+ 젬 추가</b> 버튼을 눌러 시작하세요.
                    </div>
                ) : (
                    <div className="grid grid-cols-1 gap-4">
                        {list.map(g => (
                            <GemCard key={g.id}
                                gem={g} family={family} params={params}
                                onUpdate={onUpdate} onUpdateOption={onUpdateOption} onRemove={onRemove}
                            />
                        ))}
                    </div>
                )}
            </CardBody>
        </Card>
    );
}

function GemCard({
    gem, family, params, onUpdate, onUpdateOption, onRemove
}: {
    gem: Gem; family: 'order' | 'chaos'; params: Params;
    onUpdate: (family: 'order' | 'chaos', id: string, patch: Partial<Gem>) => void;
    onUpdateOption: (family: 'order' | 'chaos', id: string, idx: number, patch: Partial<Gem['options'][number]>) => void;
    onRemove: (family: 'order' | 'chaos', id: string) => void;
}) {
    const tone = family === "order" ? "blue" : "rose";
    const need = effectiveWillRequired(gem, params);
    const pts = gemCorePoints(gem);

    return (
        <div
            className={[
                "rounded-2xl border bg-white dark:bg-zinc-900",
                "border-zinc-200 dark:border-zinc-800",
                "shadow-sm hover:shadow-md transition-shadow"
            ].join(" ")}
        >
            {/* 헤더 라인 */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-200/80 dark:border-zinc-800">
                <div className="flex items-center gap-2">
                    <Badge tone={tone}>{FAMILY_LABEL[family]} 젬</Badge>
                    <Badge tone="zinc" soft className="ml-1">의지력 {need}</Badge>
                    <Badge tone="zinc" soft>포인트 {pts}</Badge>
                </div>
                <button
                    className="text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 text-sm"
                    onClick={() => onRemove(family, gem.id)}
                >
                    삭제
                </button>
            </div>

            {/* 바디 */}
            <div className="p-4">
                {/* 1행: 효율/코어포인트 */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Field label="효율">
                        <select
                            className="border rounded-xl px-3 py-2 w-full bg-white dark:bg-zinc-900"
                            value={getGemOption(gem, '의지력 효율')?.lv || 1}
                            onChange={(e) => onUpdateOption(family, gem.id, 0, { lv: Number(e.target.value) })}
                        >
                            {[1, 2, 3, 4, 5].map(lv => <option key={lv} value={lv}>{lv}Lv</option>)}
                        </select>
                    </Field>

                    <Field label="코어 포인트">
                        <select
                            className="border rounded-xl px-3 py-2 w-full bg-white dark:bg-zinc-900"
                            value={getGemOption(gem, '코어 포인트')?.lv || 1}
                            onChange={(e) => onUpdateOption(family, gem.id, 1, { lv: Number(e.target.value) })}
                        >
                            {[1, 2, 3, 4, 5].map(lv => <option key={lv} value={lv}>{lv}Lv</option>)}
                        </select>
                    </Field>
                </div>

                {/* 2행: 세부타입/기본 의지력 */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                    <Field label="세부타입">
                        <select
                            className="border rounded-xl px-3 py-2 w-full bg-white dark:bg-zinc-900"
                            value={gem.subType}
                            onChange={(e) => onUpdate(
                                family, gem.id,
                                { subType: e.target.value as any, baseWill: baseWillBySubType(e.target.value) }
                            )}
                        >
                            {SUB_TYPES.map(st => <option key={st} value={st}>{st}</option>)}
                        </select>
                    </Field>

                    <Field label="기본 의지력">
                        <input
                            type="number"
                            className="border rounded-xl px-3 py-2 w-full bg-white dark:bg-zinc-900"
                            value={gem.baseWill}
                            onChange={(e) => onUpdate(family, gem.id, { baseWill: Number(e.target.value || 0) })}
                        />
                    </Field>
                </div>

                {/* 3행: 옵션1/옵션2 */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                    <Field label="옵션1">
                        <div className="flex gap-2">
                            <select
                                className="border rounded-xl px-3 py-2 flex-1 bg-white dark:bg-zinc-900"
                                value={gem.options[2]?.name}
                                onChange={(e) => onUpdateOption(family, gem.id, 2, { name: e.target.value })}
                            >
                                {FLEX_OPTION_POOL.map(n => <option key={n} value={n}>{n}</option>)}
                            </select>
                            <select
                                className="border rounded-xl px-3 py-2 w-28 bg-white dark:bg-zinc-900"
                                value={gem.options[2]?.lv || 1}
                                onChange={(e) => onUpdateOption(family, gem.id, 2, { lv: Number(e.target.value) })}
                            >
                                {[1, 2, 3, 4, 5].map(lv => <option key={lv} value={lv}>Lv{lv}</option>)}
                            </select>
                        </div>
                    </Field>

                    <Field label="옵션2">
                        <div className="flex gap-2">
                            <select
                                className="border rounded-xl px-3 py-2 flex-1 bg-white dark:bg-zinc-900"
                                value={gem.options[3]?.name}
                                onChange={(e) => onUpdateOption(family, gem.id, 3, { name: e.target.value })}
                            >
                                {FLEX_OPTION_POOL.map(n => <option key={n} value={n}>{n}</option>)}
                            </select>
                            <select
                                className="border rounded-xl px-3 py-2 w-28 bg-white dark:bg-zinc-900"
                                value={gem.options[3]?.lv || 1}
                                onChange={(e) => onUpdateOption(family, gem.id, 3, { lv: Number(e.target.value) })}
                            >
                                {[1, 2, 3, 4, 5].map(lv => <option key={lv} value={lv}>Lv{lv}</option>)}
                            </select>
                        </div>
                    </Field>
                </div>
            </div>
        </div>
    );
}
