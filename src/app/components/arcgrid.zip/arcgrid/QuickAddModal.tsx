'use client';

import { baseWillBySubType } from "@/app/lib/arcgrid/optimizer";
import { useEffect, useState } from "react";

const NAME_MAP: Record<string, string> = {
    "보": "보스 피해", "보스피해": "보스 피해", "보스 피해": "보스 피해",
    "추": "추가 피해", "추가피해": "추가 피해", "추가 피해": "추가 피해",
    "공": "공격력", "공격": "공격력", "공격력": "공격력",
    "낙": "낙인력", "낙인": "낙인력", "낙인력": "낙인력",
    "아피": "아군 피해 강화", "아군피해강화": "아군 피해 강화", "아군 피해 강화": "아군 피해 강화",
    "아공": "아군 공격 강화", "아군공격강화": "아군 공격 강화", "아군 공격 강화": "아군 공격 강화",
};
const FAMILY_WORD: Record<string, 'order' | 'chaos'> = {
    "order": "order", "질서": "order", "chaos": "chaos", "혼돈": "chaos"
};

export interface QuickDraft {
    family: 'order' | 'chaos';
    subType: '안정' | '침식';
    base: number;
    effLv: number;
    need: number;
    pts: number;
    opts: { name: string; lv: number }[];
}

export default function QuickAddModal({
    onClose, onConfirm
}: { onClose: () => void; onConfirm: (drafts: QuickDraft[]) => void }) {
    const [text, setText] = useState("");
    const [familyAll, setFamilyAll] = useState<'order' | 'chaos'>('order');
    const [error, setError] = useState<string | null>(null);
    const [preview, setPreview] = useState<QuickDraft[]>([]);

    function normFamily(tok: string | undefined | null, fallback: 'order' | 'chaos') {
        const t = (tok || "").trim().toLowerCase();
        return (FAMILY_WORD as any)[t] ?? fallback;
    }
    function defaultSubType(fam: 'order' | 'chaos') { return fam === 'order' ? '안정' : '침식' }

    function parseOptionToken(tok: string) {
        if (!tok) return null;
        const raw = tok.replace(/\s+/g, '');
        const m = raw.match(/^([가-힣a-zA-Z]+)(\d)$/);
        if (!m) return null;
        const nm = NAME_MAP[m[1]];
        const lv = Number(m[2]);
        if (!nm || !(lv >= 1 && lv <= 5)) return null;
        return { name: nm, lv };
    }

    function parseLine(line: string, familyDefault: 'order' | 'chaos'): QuickDraft | null {
        const toks = line.trim().split(/\s+/).filter(Boolean);
        if (!toks.length) return null;
        let i = 0;
        let fam = normFamily(toks[i], familyDefault);
        if ((FAMILY_WORD as any)[toks[i]?.trim()?.toLowerCase()]) i++;

        const need = Number(toks[i++]);
        const pts = Number(toks[i++]);
        if (!(need >= 1 && need <= 9)) throw new Error("의지력 need 1~9");
        if (!(pts >= 1 && pts <= 5)) throw new Error("포인트 1~5");

        const opts: { name: string; lv: number }[] = [];
        while (i < toks.length && opts.length < 2) {
            const o = parseOptionToken(toks[i]);
            if (o) opts.push(o);
            i++;
        }
        const subType = defaultSubType(fam);
        const base = baseWillBySubType(subType);
        let effLv = base - need;
        effLv = Math.max(1, Math.min(5, Number.isFinite(effLv) ? effLv : 1));

        return { family: fam, subType, base, effLv, need, pts, opts };
    }

    function tryParseAll() {
        setError(null);
        const lines = text.split(/\r?\n/);
        const out: QuickDraft[] = [];
        for (const ln of lines) {
            if (!ln.trim()) continue;
            try {
                const d = parseLine(ln, familyAll);
                if (d) out.push(d);
            } catch (e: any) {
                setError(`오류: "${ln.trim()}" → ${e.message}`);
                return;
            }
        }
        setPreview(out);
    }

    useEffect(() => { tryParseAll(); }, [text, familyAll]);

    return (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4" onDragOver={e => e.preventDefault()}>
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl">
                <div className="flex items-center gap-2 p-4 border-b">
                    <b>빠른 추가(텍스트)</b>
                    <div className="grow" />
                    <button className="text-zinc-600" onClick={onClose}>닫기</button>
                </div>

                <div className="flex items-center gap-2 px-4 pt-3">
                    <span className="text-sm text-zinc-600">계열 기본값</span>
                    <select className="border rounded-xl px-3 py-1.5 text-sm" value={familyAll}
                        onChange={e => setFamilyAll(e.target.value as any)}>
                        <option value="order">질서</option>
                        <option value="chaos">혼돈</option>
                    </select>
                    <div className="grow" />
                    <div className="text-xs text-zinc-500">
                        형식: <code>[계열] 의지력 포인트 [옵션1] [옵션2]</code>
                    </div>
                </div>

                <div className="px-4 pt-3">
                    <textarea
                        className="w-full h-40 border rounded-xl px-3 py-2"
                        placeholder={`예)\norder 3 5 보3 추3\nchaos 4 2 공5\n질서 6 4 보2 공1\n혼돈 5 3 낙2`}
                        value={text}
                        onChange={e => setText(e.target.value)}
                    />
                </div>

                <div className="px-4 pb-2">
                    {error ? (
                        <div className="border border-amber-400 bg-amber-50 rounded-xl p-2 text-amber-700 text-sm">{error}</div>
                    ) : (
                        <div className="border border-dashed rounded-xl p-2 text-center text-zinc-600 text-sm">
                            {preview.length ? `인식된 젬 ${preview.length}개` : "줄마다 ‘계열 의지력 포인트 옵션…’ 형식으로 입력하세요."}
                        </div>
                    )}
                </div>

                {preview.length > 0 && (
                    <div className="px-4 pb-2 space-y-2 max-h-64 overflow-auto">
                        {preview.map((d, idx) => {
                            const needDisplay = Math.max(1, d.base - d.effLv);
                            return (
                                <div key={idx} className="flex items-center gap-2 text-sm">
                                    <span className={`px-2 py-0.5 rounded-full ${d.family === 'order' ? 'bg-blue-50 text-blue-700' : 'bg-rose-50 text-rose-700'}`}>
                                        {d.family === 'order' ? '질서' : '혼돈'}
                                    </span>
                                    <span className="border rounded px-2 py-0.5 text-zinc-600">의지력 {needDisplay}</span>
                                    <span className="border rounded px-2 py-0.5 text-zinc-600">포인트 {d.pts}</span>
                                    <span className="text-xs text-zinc-500">(기본 {d.base}, 효율 Lv{d.effLv})</span>
                                    <span className="text-xs text-zinc-500">
                                        {d.opts.length ? d.opts.map(o => `${o.name} Lv${o.lv}`).join(" · ") : "옵션 없음"}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                )}

                <div className="flex items-center gap-2 p-4 border-t">
                    <button className="px-3 py-2 rounded-xl border" onClick={onClose}>취소</button>
                    <div className="grow" />
                    <button
                        className="px-3 py-2 rounded-xl bg-blue-600 text-white disabled:opacity-50"
                        disabled={!preview.length || !!error}
                        onClick={() => onConfirm(preview)}
                    >
                        {preview.length ? `젬 ${preview.length}개 추가` : "추가할 항목 없음"}
                    </button>
                </div>
            </div>
        </div>
    );
}
