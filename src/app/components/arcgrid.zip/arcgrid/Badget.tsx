'use client';
import { ReactNode } from "react";

export default function Badge({
    children, tone = "zinc", soft = false, className = ""
}: { children: ReactNode; tone?: "blue" | "rose" | "zinc" | "amber" | "emerald" | "violet"; soft?: boolean; className?: string }) {
    const tones: Record<string, string> = {
        blue: soft ? "bg-blue-50 text-blue-700 border-blue-200"
            : "bg-blue-600 text-white border-blue-600",
        rose: soft ? "bg-rose-50 text-rose-700 border-rose-200"
            : "bg-rose-600 text-white border-rose-600",
        amber: soft ? "bg-amber-50 text-amber-800 border-amber-200"
            : "bg-amber-600 text-white border-amber-600",
        emerald: soft ? "bg-emerald-50 text-emerald-700 border-emerald-200"
            : "bg-emerald-600 text-white border-emerald-600",
        violet: soft ? "bg-violet-50 text-violet-700 border-violet-200"
            : "bg-violet-600 text-white border-violet-600",
        zinc: soft ? "bg-zinc-100 text-zinc-700 border-zinc-200"
            : "bg-zinc-800 text-white border-zinc-800",
    };
    return (
        <span className={[
            "inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium",
            tones[tone], className
        ].join(" ")}>
            {children}
        </span>
    );
}
