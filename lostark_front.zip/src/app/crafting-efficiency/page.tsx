export default function CraftingEfficiencyPage() {
    return (
        <section>
            <h1 className="text-2xl font-bold">제작 효율</h1>
            <p className="mt-2 text-gray-600">재료/가격 대비 제작 효율 계산.</p>
        </section>
    );
}
